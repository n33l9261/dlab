import React from "react";

function MenteeJoinSessionScreen() {
  return (
    <div>
      <h1>This is mentee Join session page</h1>
    </div>
  );
}

export default MenteeJoinSessionScreen;
