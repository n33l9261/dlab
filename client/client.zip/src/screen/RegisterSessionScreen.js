import React from "react";

function RegisterSessionScreen() {
  return (
    <div>
      <h1>Register Session</h1>
    </div>
  );
}

export default RegisterSessionScreen;
