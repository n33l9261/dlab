import React from "react";

function HomeScreen() {
  return (
    <div>
      <h1>this home page</h1>
    </div>
  );
}

export default HomeScreen;
